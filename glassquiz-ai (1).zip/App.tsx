import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ConfigScreen } from './components/ConfigScreen';
import { LoadingScreen } from './components/LoadingScreen';
import { QuizInterface } from './components/QuizInterface';
import { ResultScreen } from './components/ResultScreen';
import { generateQuiz } from './services/geminiService';
import { saveGeneratedQuiz } from './services/storageService'; // Import storage service
import { QuizState, Question, QuizResult, ModelConfig, QuizMode } from './types';
import { Info } from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<QuizState>(QuizState.CONFIG);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [result, setResult] = useState<QuizResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [activeMode, setActiveMode] = useState<QuizMode>(QuizMode.STANDARD);

  const startQuizGeneration = async (file: File, config: ModelConfig) => {
    setState(QuizState.PROCESSING);
    setErrorMsg(null);
    setActiveMode(config.mode);
    try {
      // 1. Generate Quiz via AI
      const generatedQuestions = await generateQuiz(file, config.modelId, config.questionCount, config.mode);
      
      setQuestions(generatedQuestions);
      setState(QuizState.QUIZ_ACTIVE);

      // 2. Fire and Forget: Save to Supabase (Database)
      // Kita tidak menggunakan 'await' agar UI tidak nge-lag nunggu database response
      saveGeneratedQuiz(file, config, generatedQuestions);

    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "Terjadi kesalahan saat menghubungi AI.");
      setState(QuizState.ERROR);
    }
  };

  const handleQuizComplete = (finalResult: QuizResult) => {
    setResult(finalResult);
    setState(QuizState.RESULTS);
  };

  const resetApp = () => {
    setQuestions([]);
    setResult(null);
    setErrorMsg(null);
    setState(QuizState.CONFIG);
  };

  return (
    <div className="min-h-screen p-4 md:p-8 relative">
      {/* Analysis/About Toggle */}
      <button 
        onClick={() => setShowAnalysis(!showAnalysis)}
        className="fixed top-6 right-6 z-50 p-2 rounded-full bg-white/20 backdrop-blur-md border border-white/40 text-slate-600 hover:bg-white/40 transition-colors"
        title="Lihat Analisis Konsep"
      >
        <Info size={24} />
      </button>

      {/* Analysis Modal */}
      <AnimatePresence>
        {showAnalysis && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setShowAnalysis(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white/80 backdrop-blur-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto rounded-3xl p-8 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <h2 className="text-2xl font-semibold text-slate-800 mb-4">Analisis & Konsep Kognitif</h2>
              <div className="prose prose-slate prose-sm text-slate-600">
                <p><strong>Scaffolding Mode (Vygotsky's ZPD):</strong> Mode ini tidak mengacak soal, melainkan menyusunnya dari 'Basic Recall' -> 'Understanding' -> 'Analysis'. Ini membantu pengguna membangun jembatan pengetahuan (scaffold) sebelum menghadapi materi sulit.</p>
                <p><strong>Cognitive Load (Time Rush):</strong> Membatasi waktu menjawab memaksa otak untuk melakukan pemrosesan informasi cepat (heuristik), melatih intuisi materi.</p>
                <p><strong>Mastery Learning (Survival):</strong> Konsep "High Stakes" dimana kesalahan memiliki konsekuensi nyata, meningkatkan atensi dan retensi memori.</p>
                <p><strong>Database Integration:</strong> Setiap quiz yang berhasil dibuat akan otomatis disimpan ke Supabase untuk analisis data jangka panjang tanpa mengganggu performa UI pengguna.</p>
              </div>
              <button 
                onClick={() => setShowAnalysis(false)}
                className="mt-8 px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors w-full"
              >
                Tutup & Coba Aplikasi
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-5xl mx-auto pt-12 md:pt-20">
        <AnimatePresence mode='wait'>
          {state === QuizState.CONFIG && (
            <motion.div key="config" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ConfigScreen onStart={startQuizGeneration} />
            </motion.div>
          )}

          {state === QuizState.PROCESSING && (
            <motion.div key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <LoadingScreen />
            </motion.div>
          )}

          {state === QuizState.QUIZ_ACTIVE && (
            <motion.div key="quiz" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <QuizInterface questions={questions} mode={activeMode} onComplete={handleQuizComplete} />
            </motion.div>
          )}

          {state === QuizState.RESULTS && result && (
            <motion.div key="results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <ResultScreen result={result} onReset={resetApp} />
            </motion.div>
          )}

          {state === QuizState.ERROR && (
            <motion.div key="error" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center mt-20">
              <div className="bg-red-50/50 backdrop-blur-md border border-red-200 p-8 rounded-3xl inline-block max-w-md">
                <h3 className="text-red-800 text-xl font-medium mb-2">Oops, Ada Masalah</h3>
                <p className="text-red-600 mb-6">{errorMsg}</p>
                <button 
                  onClick={resetApp}
                  className="px-6 py-2 bg-red-100 text-red-700 rounded-xl hover:bg-red-200 transition-colors font-medium"
                >
                  Coba Lagi
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default App;