export enum QuizState {
  CONFIG = 'CONFIG',
  PROCESSING = 'PROCESSING',
  QUIZ_ACTIVE = 'QUIZ_ACTIVE',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}

export enum QuizMode {
  STANDARD = 'STANDARD',
  SCAFFOLDING = 'SCAFFOLDING', // Easy -> Hard (Guided)
  TIME_RUSH = 'TIME_RUSH',     // Timer per question
  SURVIVAL = 'SURVIVAL'        // 3 Lives only
}

export interface Question {
  id: number;
  text: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  keyPoint: string; // New field for the core concept (2-3 words)
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface QuizResult {
  correctCount: number;
  totalQuestions: number;
  score: number;
  mode: QuizMode;
  answers: { questionId: number; selectedIndex: number; isCorrect: boolean }[];
}

export interface ModelConfig {
  modelId: string;
  questionCount: number;
  mode: QuizMode;
}

export const AVAILABLE_MODELS = [
  { id: "gemma-3-27b-it", label: "Gemma 3 (27B) - Experimental Cepat" },
  { id: "gemini-3-flash-preview", label: "Gemini 3 Flash - Paling Pintar" },
  { id: "gemini-2.5-flash", label: "Gemini 2.5 Flash - Standard & Stabil" },
  { id: "gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite - Ringan" },
  { id: "gemini-2.5-pro", label: "Gemini 2.5 Pro - Advanced Reasoning" },
];