/**
 * ==========================================
 * GEMINI AI SERVICE
 * ==========================================
 */

import { GoogleGenAI, Type } from "@google/genai";
import { Question, QuizMode } from "../types";

// User provided API Key
const DEFAULT_API_KEY = "AIzaSyBmnrzaBw8xSJhNLVbJYhG-tmTpEgXN1Xs";

// Helper to convert file to base64
const fileToGenerativePart = async (file: File): Promise<{ inlineData: { data: string; mimeType: string } } | { text: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    // For text based files, we read as text
    if (file.type === "text/markdown" || file.type === "text/plain" || file.name.endsWith('.md')) {
      reader.onloadend = () => {
        resolve({ text: reader.result as string });
      };
      reader.readAsText(file);
    } else {
      // For PDF/Images, we read as base64
      reader.onloadend = () => {
        const base64Data = (reader.result as string).split(',')[1];
        resolve({
          inlineData: {
            data: base64Data,
            mimeType: file.type || 'application/pdf',
          },
        });
      };
      reader.readAsDataURL(file);
    }
    reader.onerror = reject;
  });
};

export const generateQuiz = async (
  file: File,
  modelId: string,
  questionCount: number,
  mode: QuizMode
): Promise<Question[]> => {
  
  // Use Env Var if available, otherwise use Default Key
  const apiKey = process.env.API_KEY || DEFAULT_API_KEY;

  if (!apiKey) {
    throw new Error("API Key Google Gemini belum dikonfigurasi.");
  }

  const ai = new GoogleGenAI({ apiKey: apiKey });

  // Prepare the file part
  const filePart = await fileToGenerativePart(file);

  let specificInstruction = "";
  if (mode === QuizMode.SCAFFOLDING) {
    specificInstruction = `
      CRITICAL: Design the questions with a progressive learning curve (Scaffolding).
      - First 30%: Basic concepts, definitions, and recall (Easy).
      - Next 40%: Understanding relationships and comparisons (Medium).
      - Final 30%: Application, analysis, and complex scenarios (Hard).
    `;
  } else if (mode === QuizMode.SURVIVAL) {
    specificInstruction = `
      CRITICAL: These questions should be tricky and test deep understanding. 
      Focus on common misconceptions and edge cases.
    `;
  }

  const prompt = `
    Analyze the provided document content thoroughly.
    Create a quiz with exactly ${questionCount} multiple-choice questions.
    
    ${specificInstruction}
    
    CRITICAL STYLE REQUIREMENTS (To prevent eye strain):
    1. **CONCISE QUESTIONS**: Questions MUST be short and direct (max 2 sentences). Avoid fluff.
    2. **SHORT OPTIONS**: Options must be to the point (max 10 words).
    3. **KEY POINT**: Extract the specific core concept (max 3 words) as 'keyPoint' (e.g. "Hukum Newton", "Fotosintesis").
    4. **EXPLANATION**: Keep it conversational but short (max 2 sentences).
    
    Requirements:
    1. Language: Indonesian (Bahasa Indonesia).
    2. Format: Return ONLY a valid JSON array.
    3. Options: Provide exactly 4 options per question.
    4. Difficulty: Label each question as 'Easy', 'Medium', or 'Hard'.
    
    Schema Structure:
    [
      {
        "id": 1,
        "text": "Short question text?",
        "options": ["Short Option A", "Short Option B", "C", "D"],
        "correctIndex": 0, 
        "explanation": "Brief explanation why.",
        "keyPoint": "Core Concept Name",
        "difficulty": "Easy"
      }
    ]
  `;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: {
      parts: [
        filePart as any,
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            text: { type: Type.STRING },
            options: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            correctIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING },
            keyPoint: { type: Type.STRING, description: "Short topic tag (max 3 words)" },
            difficulty: { type: Type.STRING, enum: ["Easy", "Medium", "Hard"] }
          },
          required: ["id", "text", "options", "correctIndex", "explanation", "difficulty", "keyPoint"]
        }
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response generated from the model.");
  }

  try {
    let quizData = JSON.parse(text) as Question[];
    
    // Post-processing: Sort if Scaffolding mode is active
    if (mode === QuizMode.SCAFFOLDING) {
      const difficultyOrder = { 'Easy': 1, 'Medium': 2, 'Hard': 3 };
      quizData = quizData.sort((a, b) => difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty]);
    }

    return quizData;
  } catch (e) {
    console.error("Failed to parse Gemini JSON response", e);
    throw new Error("The AI response was not valid JSON. Try reducing question count.");
  }
};