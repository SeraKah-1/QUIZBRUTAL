/**
 * ==========================================
 * STORAGE SERVICE (ONE-WAY / FIRE & FORGET)
 * ==========================================
 * 
 * This service handles saving generated quizzes to the database.
 * It is designed to fail silently if the database is not configured,
 * ensuring the main user experience (Quiz Generation) is never interrupted.
 */

import { supabase } from "../lib/supabaseClient";
import { Question, ModelConfig } from "../types";

export const saveGeneratedQuiz = async (
  file: File,
  config: ModelConfig,
  questions: Question[]
) => {
  // 1. Safety Check: If Supabase is not initialized (missing keys), abort immediately.
  if (!supabase) {
    console.log("Storage skipped: Supabase credentials not found. (App is running in local/offline mode for storage)");
    return;
  }

  try {
    // Extract a topic summary from the first question's keyPoint if available
    const topicSummary = questions.length > 0 ? questions[0].keyPoint : "General Topic";

    // 2. Fire Request
    const { error } = await supabase
      .from('generated_quizzes')
      .insert([
        {
          file_name: file.name,
          model_id: config.modelId,
          mode: config.mode,
          topic_summary: topicSummary,
          questions: questions // Stored as JSONB
        }
      ]);

    // 3. Log result (for debugging only)
    if (error) {
      console.warn("Failed to save quiz to DB:", error.message);
    } else {
      console.log("Quiz successfully archived to Supabase.");
    }
  } catch (err) {
    // Catch-all to ensure the UI never crashes due to a background save error
    console.error("Unexpected error in storage service (Safe to ignore):", err);
  }
};