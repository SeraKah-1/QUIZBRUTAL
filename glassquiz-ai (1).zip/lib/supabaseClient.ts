/**
 * ==========================================
 * SUPABASE CLIENT CONFIGURATION
 * ==========================================
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Prioritize Environment Variables, fallback to Hardcoded User Keys
const supabaseUrl = process.env.SUPABASE_URL || "https://hofbqpsdpsmbzleyarnn.supabase.co";
const supabaseKey = process.env.SUPABASE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhvZmJxcHNkcHNtYnpsZXlhcm5uIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA2MTA0NjYsImV4cCI6MjA4NjE4NjQ2Nn0.--3ozF4EYyP1UZOAWkzJf55gJDs3PAbHwy8yZkT4xUE";

// Safe Initialization:
// We only initialize the client if credentials exist.
// Otherwise, we export null to prevent the "supabaseUrl is required" crash.
export const supabase: SupabaseClient | null = (supabaseUrl && supabaseKey) 
  ? createClient(supabaseUrl, supabaseKey) 
  : null;