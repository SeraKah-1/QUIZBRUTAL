import React from 'react';
import { motion } from 'framer-motion';

export const LoadingScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center">
      <div className="relative w-32 h-32 mb-8">
        <motion.div 
          className="absolute inset-0 border-4 border-indigo-200/30 rounded-full"
        />
        <motion.div 
          className="absolute inset-0 border-t-4 border-indigo-500 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
        />
        <motion.div 
          className="absolute inset-4 bg-white/20 backdrop-blur-md rounded-full shadow-inner"
          animate={{ scale: [0.9, 1.1, 0.9] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>
      
      <motion.h2 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-2xl font-light text-slate-700 mb-2"
      >
        Menganalisis Dokumen
      </motion.h2>
      <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="text-slate-400 max-w-xs mx-auto"
      >
        AI sedang membaca, memahami, dan membuat soal untuk Anda. Mohon tunggu sebentar.
      </motion.p>
    </div>
  );
};