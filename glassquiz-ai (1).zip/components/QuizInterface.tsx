import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, ArrowRight, Clock, Heart, Flame, Sparkles, Lightbulb } from 'lucide-react';
import { Question, QuizResult, QuizMode } from '../types';
import { GlassButton } from './GlassButton';

interface QuizInterfaceProps {
  questions: Question[];
  mode: QuizMode;
  onComplete: (result: QuizResult) => void;
}

export const QuizInterface: React.FC<QuizInterfaceProps> = ({ questions, mode, onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [answers, setAnswers] = useState<{ questionId: number; selectedIndex: number; isCorrect: boolean }[]>([]);
  
  // Gamification States
  const [streak, setStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [timeLeft, setTimeLeft] = useState(20);

  const currentQuestion = questions[currentIndex];

  // --- CRITICAL FIX: PREVENT WHITESCREEN ---
  // If currentQuestion is undefined (index out of bounds) or questions array is empty,
  // return null immediately to prevent accessing properties of undefined.
  if (!currentQuestion) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-500">
        <p>Memuat data pertanyaan...</p>
      </div>
    );
  }
  // -----------------------------------------

  // Timer Logic
  useEffect(() => {
    if (mode !== QuizMode.TIME_RUSH || isAnswered) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentIndex, isAnswered, mode]);

  useEffect(() => {
    if (mode === QuizMode.TIME_RUSH) setTimeLeft(20);
  }, [currentIndex, mode]);

  const handleTimeOut = () => {
    handleAnswer(-1, false);
  };

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    const isCorrect = index === currentQuestion.correctIndex;
    handleAnswer(index, isCorrect);
  };

  const handleAnswer = (index: number, isCorrect: boolean) => {
    setSelectedOption(index);
    setIsAnswered(true);

    setAnswers(prev => [...prev, { 
      questionId: currentQuestion.id, 
      selectedIndex: index, 
      isCorrect 
    }]);

    // Gamification Logic
    if (isCorrect) {
      setStreak(prev => prev + 1);
    } else {
      setStreak(0);
      if (mode === QuizMode.SURVIVAL) {
        if (lives - 1 <= 0) setLives(0);
        else setLives(prev => prev - 1);
      }
    }
  };

  const handleNext = () => {
    if (mode === QuizMode.SURVIVAL && lives === 0) {
      finishQuiz();
      return;
    }

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const correctCount = answers.filter(a => a.isCorrect).length;
    onComplete({
      correctCount,
      totalQuestions: questions.length,
      score: correctCount * 10,
      mode,
      answers
    });
  };

  // Animation Variants
  const cardVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { opacity: 1, y: 0, scale: 1 },
    exit: { opacity: 0, x: -50, scale: 0.95 },
    shake: { x: [0, -10, 10, -10, 10, 0], transition: { duration: 0.4 } }
  };

  const optionVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: (i: number) => ({ opacity: 1, x: 0, transition: { delay: i * 0.1 } }),
  };

  // Safe Check for options to prevent crash if AI returns malformed JSON
  const safeOptions = Array.isArray(currentQuestion.options) ? currentQuestion.options : [];

  return (
    <div className="max-w-3xl mx-auto px-4">
      {/* Dynamic Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-3">
          {/* Progress Pill */}
          <div className="bg-white/40 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/50 text-slate-600 font-semibold text-sm shadow-sm">
            {currentIndex + 1} <span className="text-slate-400 font-normal">/ {questions.length}</span>
          </div>
          
          {/* Streak Badge */}
          <AnimatePresence>
            {streak > 1 && (
              <motion.div 
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                className="flex items-center bg-orange-100 text-orange-600 px-3 py-2 rounded-2xl border border-orange-200"
              >
                <Flame size={18} className="fill-orange-500 mr-1 animate-pulse" />
                <span className="font-bold text-sm">{streak}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="flex items-center gap-2">
           {mode === QuizMode.SURVIVAL && (
            <div className="flex items-center space-x-1 bg-rose-100 text-rose-600 px-3 py-2 rounded-2xl border border-rose-200">
              <Heart size={18} className="fill-rose-500" />
              <span className="font-bold text-sm">{lives}</span>
            </div>
          )}
           {mode === QuizMode.TIME_RUSH && (
            <div className={`flex items-center space-x-1 px-3 py-2 rounded-2xl border ${timeLeft < 5 ? 'bg-red-100 text-red-600 border-red-200' : 'bg-indigo-50 text-indigo-600 border-indigo-200'}`}>
              <Clock size={18} />
              <span className="font-bold text-sm">{timeLeft}s</span>
            </div>
          )}
        </div>
      </div>

      <AnimatePresence mode='wait'>
        <motion.div
          key={currentIndex}
          variants={cardVariants}
          initial="hidden"
          animate={isAnswered && selectedOption !== currentQuestion.correctIndex ? "shake" : "visible"}
          exit="exit"
          transition={{ duration: 0.4, type: "spring" }}
          className="relative"
        >
          {/* Main Question Card */}
          <div className="bg-white/50 backdrop-blur-2xl border border-white/80 rounded-[2rem] p-8 md:p-10 shadow-xl shadow-indigo-500/10">
            
            {/* Key Point Badge (The "Bite-sized" context) */}
            <div className="flex justify-center mb-6">
               <span className="inline-flex items-center px-4 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-xs font-bold uppercase tracking-wider shadow-sm">
                 <Sparkles size={12} className="mr-2" />
                 {currentQuestion.keyPoint || "Konsep Kunci"}
               </span>
            </div>

            {/* Question Text - Larger and cleaner */}
            <h2 className="text-2xl md:text-3xl font-medium text-slate-800 text-center mb-10 leading-snug tracking-tight">
              {currentQuestion.text}
            </h2>

            {/* Options */}
            <div className="grid grid-cols-1 gap-4">
              {safeOptions.map((option, idx) => {
                let styles = "bg-white/70 border-white/60 text-slate-600 hover:bg-white hover:border-indigo-200 hover:scale-[1.01]";
                
                if (isAnswered) {
                   if (idx === currentQuestion.correctIndex) {
                     styles = "bg-emerald-500 text-white border-emerald-500 shadow-lg shadow-emerald-500/30 scale-[1.02] z-10";
                   } else if (idx === selectedOption) {
                     styles = "bg-rose-100 border-rose-200 text-rose-500 opacity-80";
                   } else {
                     styles = "bg-slate-50 border-transparent text-slate-300 opacity-50";
                   }
                }

                return (
                  <motion.button
                    key={idx}
                    custom={idx}
                    variants={optionVariants}
                    initial="hidden"
                    animate="visible"
                    onClick={() => handleOptionSelect(idx)}
                    disabled={isAnswered}
                    className={`
                      relative w-full p-5 rounded-2xl border-2 text-lg font-medium transition-all duration-300
                      flex items-center justify-center text-center
                      ${styles}
                    `}
                  >
                    {option}
                    {isAnswered && idx === currentQuestion.correctIndex && (
                      <Check className="absolute right-5 text-white" size={24} />
                    )}
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Feedback / Scaffolding Panel */}
          <AnimatePresence>
            {isAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6"
              >
                <div className={`
                  rounded-3xl p-6 border-2 
                  ${selectedOption === currentQuestion.correctIndex 
                    ? 'bg-emerald-50/80 border-emerald-100' 
                    : 'bg-white/60 border-indigo-100'}
                `}>
                  <div className="flex items-start gap-4">
                     <div className={`p-3 rounded-2xl shrink-0 ${selectedOption === currentQuestion.correctIndex ? 'bg-emerald-100 text-emerald-600' : 'bg-indigo-100 text-indigo-600'}`}>
                       <Lightbulb size={24} />
                     </div>
                     <div>
                       <h3 className="font-bold text-slate-800 text-lg mb-1">
                         {selectedOption === currentQuestion.correctIndex ? "Tepat Sekali!" : "Koreksi Konsep"}
                       </h3>
                       <p className="text-slate-600 leading-relaxed">
                         {currentQuestion.explanation}
                       </p>
                     </div>
                  </div>
                  
                  <div className="mt-6 flex justify-end">
                    <GlassButton onClick={handleNext} className={`
                      pl-8 pr-6 shadow-xl 
                      ${selectedOption === currentQuestion.correctIndex ? 'bg-emerald-500 text-white border-emerald-400 hover:bg-emerald-600' : ''}
                    `}>
                      {mode === QuizMode.SURVIVAL && lives === 0 ? "Lihat Hasil" : currentIndex === questions.length - 1 ? "Selesai" : "Lanjut"} 
                      <ArrowRight size={20} className="ml-2" />
                    </GlassButton>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </motion.div>
      </AnimatePresence>
    </div>
  );
};