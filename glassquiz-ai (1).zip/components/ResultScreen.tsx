import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import { QuizResult } from '../types';
import { GlassButton } from './GlassButton';

interface ResultScreenProps {
  result: QuizResult;
  onReset: () => void;
}

export const ResultScreen: React.FC<ResultScreenProps> = ({ result, onReset }) => {
  const percentage = Math.round((result.correctCount / result.totalQuestions) * 100);
  
  let gradeColor = "text-indigo-600";
  let gradeMessage = "Luar Biasa";
  
  if (percentage < 60) {
    gradeColor = "text-amber-600";
    gradeMessage = "Perlu Latihan Lagi";
  } else if (percentage < 80) {
    gradeColor = "text-emerald-600";
    gradeMessage = "Bagus";
  }

  return (
    <div className="max-w-2xl mx-auto text-center">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white/30 backdrop-blur-xl border border-white/50 rounded-3xl p-12 shadow-2xl shadow-indigo-500/5 mb-8"
      >
        <h2 className="text-slate-500 font-medium mb-8 tracking-wide uppercase text-sm">Hasil Akhir</h2>
        
        <div className="relative inline-block mb-8">
          <svg className="w-48 h-48 transform -rotate-90">
            <circle
              className="text-white/40"
              strokeWidth="12"
              stroke="currentColor"
              fill="transparent"
              r="88"
              cx="96"
              cy="96"
            />
            <motion.circle
              className={percentage < 60 ? "text-amber-400" : percentage < 80 ? "text-emerald-400" : "text-indigo-400"}
              strokeWidth="12"
              strokeDasharray={552}
              strokeDashoffset={552 - (552 * percentage) / 100}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
              r="88"
              cx="96"
              cy="96"
              initial={{ strokeDashoffset: 552 }}
              animate={{ strokeDashoffset: 552 - (552 * percentage) / 100 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          </svg>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <span className="text-5xl font-light text-slate-800">{percentage}%</span>
          </div>
        </div>

        <h3 className={`text-2xl font-medium ${gradeColor} mb-2`}>{gradeMessage}</h3>
        <p className="text-slate-500">
          Benar {result.correctCount} dari {result.totalQuestions} soal
        </p>

        <div className="mt-12">
          <GlassButton onClick={onReset} variant="secondary" className="flex items-center mx-auto">
            <RefreshCw size={18} className="mr-2" />
            Buat Quiz Baru
          </GlassButton>
        </div>
      </motion.div>
    </div>
  );
};