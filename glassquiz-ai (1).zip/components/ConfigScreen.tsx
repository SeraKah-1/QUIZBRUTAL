import React, { useState } from 'react';
import { Upload, FileText, Settings, AlertCircle, Zap, TrendingUp, Skull, Layout } from 'lucide-react';
import { motion } from 'framer-motion';
import { AVAILABLE_MODELS, ModelConfig, QuizMode } from '../types';
import { GlassButton } from './GlassButton';

interface ConfigScreenProps {
  onStart: (file: File, config: ModelConfig) => void;
}

export const ConfigScreen: React.FC<ConfigScreenProps> = ({ onStart }) => {
  const [file, setFile] = useState<File | null>(null);
  const [modelId, setModelId] = useState(AVAILABLE_MODELS[2].id);
  const [questionCount, setQuestionCount] = useState(10);
  const [mode, setMode] = useState<QuizMode>(QuizMode.STANDARD);
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const modes = [
    { 
      id: QuizMode.STANDARD, 
      label: 'Standard', 
      desc: 'Mode klasik. Santai, tanpa tekanan waktu.',
      icon: <Layout size={20} />
    },
    { 
      id: QuizMode.SCAFFOLDING, 
      label: 'Learning Guide', 
      desc: 'Belajar bertahap. Dari mudah ke sulit (Scaffolding).',
      icon: <TrendingUp size={20} />
    },
    { 
      id: QuizMode.TIME_RUSH, 
      label: 'Time Rush', 
      desc: 'Melatih kecepatan berpikir. 20 detik per soal.',
      icon: <Zap size={20} />
    },
    { 
      id: QuizMode.SURVIVAL, 
      label: 'Survival', 
      desc: 'Ujian mental. Hanya 3 nyawa (kesempatan salah).',
      icon: <Skull size={20} />
    },
  ];

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 pb-12">
      <div className="text-center space-y-2">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-light text-slate-800 tracking-tight"
        >
          GlassQuiz <span className="font-semibold text-indigo-600/80">AI</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-slate-500 font-light"
        >
          Platform pembelajaran adaptif berbasis kognitif.
        </motion.p>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white/30 backdrop-blur-xl border border-white/50 rounded-3xl p-8 shadow-2xl shadow-indigo-500/5"
      >
        {/* File Upload */}
        <div className="mb-8">
          <label className="block text-sm font-medium text-slate-700 mb-3 ml-1">
            Materi Pembelajaran
          </label>
          <div 
            className={`
              relative group cursor-pointer
              border-2 border-dashed rounded-2xl p-8 
              transition-all duration-300 ease-out
              flex flex-col items-center justify-center text-center
              ${dragActive 
                ? 'border-indigo-500 bg-indigo-50/50' 
                : file 
                  ? 'border-emerald-400/50 bg-emerald-50/30' 
                  : 'border-slate-300 hover:border-indigo-400 hover:bg-white/40'
              }
            `}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            <input 
              id="file-upload" 
              type="file" 
              className="hidden" 
              accept=".pdf,.md,.txt,.ppt,.pptx"
              onChange={handleChange} 
            />
            
            {file ? (
              <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                <div className="flex items-center justify-center space-x-3 text-slate-800 font-medium">
                  <FileText size={24} className="text-emerald-600" />
                  <span>{file.name}</span>
                </div>
                <p className="text-emerald-600 text-xs mt-2 bg-emerald-100/50 py-1 px-3 rounded-full inline-block">
                  Siap untuk dianalisis
                </p>
              </motion.div>
            ) : (
              <div className="text-slate-400">
                <Upload size={32} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">Drop PDF/MD disini atau klik untuk upload</p>
              </div>
            )}
          </div>
        </div>

        {/* Mode Selection Grid */}
        <div className="mb-8">
          <label className="block text-sm font-medium text-slate-700 mb-3 ml-1">
            Mode Kognitif
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {modes.map((m) => (
              <div 
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`
                  p-4 rounded-xl border cursor-pointer transition-all duration-200
                  flex items-start space-x-4
                  ${mode === m.id 
                    ? 'bg-indigo-50/80 border-indigo-500/50 shadow-md ring-1 ring-indigo-500/20' 
                    : 'bg-white/40 border-white/60 hover:bg-white/60 hover:border-indigo-200'
                  }
                `}
              >
                <div className={`mt-1 p-2 rounded-lg ${mode === m.id ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-500'}`}>
                  {m.icon}
                </div>
                <div>
                  <h3 className={`font-medium ${mode === m.id ? 'text-indigo-900' : 'text-slate-700'}`}>{m.label}</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{m.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Configuration Sliders */}
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="space-y-3">
            <label className="flex items-center text-sm font-medium text-slate-700 ml-1">
              <Settings size={16} className="mr-2 text-indigo-500" /> Model Intelligence
            </label>
            <div className="relative">
              <select 
                value={modelId}
                onChange={(e) => setModelId(e.target.value)}
                className="w-full appearance-none bg-white/40 border border-white/60 rounded-xl px-4 py-3 pr-8 text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {AVAILABLE_MODELS.map(model => (
                  <option key={model.id} value={model.id}>{model.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-center text-sm font-medium text-slate-700 ml-1">
              <AlertCircle size={16} className="mr-2 text-indigo-500" /> Total Soal: {questionCount}
            </label>
            <input 
              type="range" 
              min="5" 
              max="100" 
              step="5"
              value={questionCount}
              onChange={(e) => setQuestionCount(Number(e.target.value))}
              className="w-full h-2 bg-slate-200/50 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
          </div>
        </div>

        <GlassButton 
          fullWidth 
          onClick={() => file && onStart(file, { modelId, questionCount, mode })}
          disabled={!file}
        >
          {file ? "Mulai Sesi Belajar" : "Upload Materi Dulu"}
        </GlassButton>
      </motion.div>
    </div>
  );
};